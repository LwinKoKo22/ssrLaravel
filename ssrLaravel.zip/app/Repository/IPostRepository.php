<?php
namespace App\Repository;
interface IPostRepository{
    public function getAllPosts();
}